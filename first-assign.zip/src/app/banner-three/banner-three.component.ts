import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-three',
  templateUrl: './banner-three.component.html',
  styleUrls: ['./banner-three.component.css']
})
export class BannerThreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
