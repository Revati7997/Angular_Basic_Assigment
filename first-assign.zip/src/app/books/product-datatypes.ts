export class Products_books {
  productname: string;
  author: string;
  price: number;
  image: string;
  quantity: number;
}
