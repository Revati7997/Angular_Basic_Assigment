export const PRODUCTS = [
  {
    productname: "The Fault in Our Stars",
    author: "John Green",
    price: 200,
    Instock: 5,
    image: "../../assets/images/the_fault_in_our_stars.jpg",
    quantity: 0
  },
  {
    productname: "Love, Rosie ",
    author: "Cecelia Ahern",
    price: 325,
    Instock: 7,
    image: "../../assets/images/love_rosie.jpg",
    quantity: 0
  },
  {
    productname: "Shiva Trilogy",
    author: "Amish Tripathi ",
    price: 750,
    Instock: 19,
    image: "../../assets/images/Amish_Trology.png",
    quantity: 0
  },
  {
    productname: "The 3 Mistakes Of My Life",
    author: "Chetan Bhagat",
    price: 150,
    Instock: 50,
    image: "../../assets/images/3_mistakes_of_my_life.jpg",
    quantity: 0
  },
  {
    productname: "The Perfect Us",
    author: "Durjoy Datta",
    price: 170,
    Instock: 13,
    image: "../../assets/images/The-Perfect-Us.jpg",
    quantity: 0
  },
  {
    productname: " Harry Potter",
    author: "J.K.Rowling",
    price: 2750,
    Instock: 22,
    image: "../../assets/images/HP_book.jpg",
    quantity: 0
  },
  {
    productname: "The Last Lecture",
    author: "Randy Pausch, Jeffrey Zaslow",
    price: 295,
    Instock: 13,
    image: "../../assets/images/Last-Lecture.jpg",
    quantity: 0
  },
  {
    productname: "The Book of Time",
    author: "Guillaume Prevost",
    price: 1200,
    Instock: 22,
    image: "../../assets/images/The_book_of _time.jpg",
    quantity: 0
  }
];
