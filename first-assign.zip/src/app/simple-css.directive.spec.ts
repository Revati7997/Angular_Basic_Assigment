import { SimpleCSSDirective } from './simple-css.directive';

describe('SimpleCSSDirective', () => {
  it('should create an instance', () => {
    const directive = new SimpleCSSDirective();
    expect(directive).toBeTruthy();
  });
});
