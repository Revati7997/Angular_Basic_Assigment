export const PRODUCTS = [
  {
    productname: "Bougainvillea Bonsai Tree",
    productid: 424,
    price: 2500,
    Instock: 5,
    image: "../../assets/images/Bougainvillea_Bonsai.jpg",
    quantity: 0
  },
  {
    productname: "Buttonwood Bonsai Kit",
    productid: 726,
    price: 350,
    Instock: 7,
    image: "../../assets/images/Buttonwood_Bonsai.jpg",
    quantity: 0
  },
  {
    productname: "Chinese Elm Bonsai Tree ",
    productid: 54229,
    price: 350,
    Instock: 19,
    image: "../../assets/images/Chinese_Elm_Bonsai.jpg",
    quantity: 0
  },
  {
    productname: "Clusia Bonsai Tree",
    productid: 1940,
    price: 600,
    Instock: 50,
    image: "../../assets/images/Clusia_Bonsai.jpg",
    quantity: 0
  },
  {
    productname: "Ficus Bonsai Tree",
    productid: 4415,
    price: 95,
    Instock: 13,
    image: "../../assets/images/Ficus_Bonsai.jpg",
    quantity: 0
  },
  {
    productname: "Powder Puff Bonsai Tree",
    productid: 30253,
    price: 450,
    Instock: 22,
    image: "../../assets/images/Power_Puff_Bonsai.jpg",
    quantity: 0
  },
  {
    productname: "Money Tree Bonsai Tree",
    productid: 94225,
    price: 190,
    Instock: 13,
    image: "../../assets/images/Money_Tree.jpg",
    quantity: 0
  },
  {
    productname: "Juniper Bonsai Tree",
    productid: 1336,
    price: 199,
    Instock: 22,
    image: "../../assets/images/Juniper.jpg",
    quantity: 0
  }
];
