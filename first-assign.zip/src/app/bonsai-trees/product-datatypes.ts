export class Products {
  productname: string;
  productid: number;
  price: number;
  image: string;
  quantity: number;
}
