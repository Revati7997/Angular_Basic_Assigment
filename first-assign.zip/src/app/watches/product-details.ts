export const PRODUCTS = [
  {
    productname: "Brain Freezer Watch",
    productid: 3467,
    price: 1490,
    Instock: 19,
    image: "../../assets/images/Brainfreezer.jpg",
    quantity: 0
  },
  {
    productname: "Svm Couple Watch",
    productid: 31234,
    price: 379,
    Instock: 5,
    image: "../../assets/images/SVM.jpg",
    quantity: 0
  },
  {
    productname: "TItan Neo Watch",
    productid: 1585,
    price: 1995,
    Instock: 22,
    image: "../../assets/images/titan.jpg",
    quantity: 0
  },
  {
    productname: "MI Band 3 ",
    productid: 90095,
    price: 1999,
    Instock: 7,
    image: "../../assets/images/MI_band3.jpg",
    quantity: 0
  },
  {
    productname: "Fastrack Digital Watch",
    productid: 9045,
    price: 3035,
    Instock: 50,
    image: "../../assets/images/fastrack.jpg",
    quantity: 0
  },
  {
    productname: "Fossil Analog Watch",
    productid: 2234,
    price: 7695,
    Instock: 13,
    image: "../../assets/images/fossil.jpg",
    quantity: 0
  },

  {
    productname: "Apple Sport Loop Watch",
    productid: 440,
    price: 49899,
    Instock: 13,
    image: "../../assets/images/apple.jpg",
    quantity: 0
  },
  {
    productname: " Rado Hyperchrome Watch",
    productid: 32115,
    price: 105200,
    Instock: 22,
    image: "../../assets/images/rado.jpg",
    quantity: 0
  }
];
