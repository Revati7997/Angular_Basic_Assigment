export class Products_watches {
  productname: string;
  productid: number;
  price: number;
  image: string;
  quantity: number;
}
