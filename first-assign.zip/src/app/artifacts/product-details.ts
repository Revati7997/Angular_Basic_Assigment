export const PRODUCTS = [
  {
    productname: "Khyaat Ganesha Polystone",
    productid: 236,
    price: 2890,
    Instock: 5,
    image: "../../assets/images/ganapati.jpg",
    quantity: 0
  },
  {
    productname: "Horse Tableware Antique",
    productid: 1198,
    price: 579,
    Instock: 7,
    image: "../../assets/images/horse.png",
    quantity: 0
  },
  {
    productname: "ANS MUSICAL ARTIFACTS ",
    productid: 4229,
    price: 750,
    Instock: 19,
    image: "../../assets/images/musical.jpg",
    quantity: 0
  },
  {
    productname: " Karigari Wooden Ship",
    productid: 19410,
    price: 495,
    Instock: 50,
    image: "../../assets/images/boat.jpg",
    quantity: 0
  },
  {
    productname: " Thinking Man Tableware",
    productid: 4015,
    price: 1995,
    Instock: 13,
    image: "../../assets/images/man.jpg",
    quantity: 0
  },
  {
    productname: "Khan Handmade Cycle",
    productid: 3023,
    price: 268,
    Instock: 22,
    image: "../../assets/images/cycle.jpg",
    quantity: 0
  },
  {
    productname: "Tied Ribbons Showpiece",
    productid: 925,
    price: 899,
    Instock: 13,
    image: "../../assets/images/homedecor.jpg",
    quantity: 0
  },
  {
    productname: "Jhaiji Prayer Wheel  ",
    productid: 1336,
    price: 360,
    Instock: 22,
    image: "../../assets/images/wheel.jpg",
    quantity: 0
  }
];
