export class Products_artifact {
  productname: string;
  productid: number;
  price: number;
  image: string;
  quantity: number;
}
